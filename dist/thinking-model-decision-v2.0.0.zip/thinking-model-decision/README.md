# 思维模型决策工具

打包版本 **2.0.0**。

请保留完整的 `thinking-model-decision` 文件夹。`SKILL.md` 需要和 `references/` 等配套资源一起使用，不要只复制入口文件。

在支持 Skills 的智能体中按该产品方式安装；只能读工作区文件时，明确要求本次会话读取完整目录。

开始时说：请用思维模型决策工具，先每轮问我一个关键问题，问题清楚后组建工具箱，给出解决方案和 HTML 实施步骤。我的困惑是……

先确认助手实际读到入口、模型卡及运行文件；仅下载或看到技能名称不等于已能使用。个人报告留在当前任务。

- [开始使用与操作示范](https://github.com/sushengs-creator/thinking-model-decision#readme)
- [安装与更新说明](https://github.com/sushengs-creator/thinking-model-decision/blob/main/docs/INSTALL.md)
