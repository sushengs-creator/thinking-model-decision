# 思维模型决策工具

打包版本 **1.6.0**。

请保留完整的 `thinking-model-decision` 文件夹。`SKILL.md` 需要和 `references/` 等配套资源一起使用，不要只复制入口文件。

- [开始使用与操作示范](https://github.com/sushengs-creator/thinking-model-decision#readme)
- [安装与更新说明](https://github.com/sushengs-creator/thinking-model-decision/blob/main/docs/INSTALL.md)
